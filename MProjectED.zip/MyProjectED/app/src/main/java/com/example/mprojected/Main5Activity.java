package com.example.mprojected;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

@SuppressWarnings("ALL")
public class Main5Activity extends AppCompatActivity {
    ImageView final_image_id;
    Button dwld_final_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        final_image_id=(ImageView)findViewById(R.id.last_image);
        dwld_final_id= (Button)findViewById(R.id.dwld_last);


    }
}
