package com.example.mprojected;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@SuppressWarnings("ALL")
public class Main4Activity extends AppCompatActivity {
    ImageView enhanced_view;
    Button detect_button_id;
    Button dwld_button_id;
    Exception ex;
    Bitmap bitmap;
    private final String TAG = "abc";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        enhanced_view=(ImageView)findViewById(R.id.enhanced);
        detect_button_id=(Button)findViewById(R.id.dete_out);
        dwld_button_id=(Button)findViewById(R.id.dwld_last);

        detect_button_id.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Main5Activity.class);
                startActivity(i);
            }
        });

    }
    public void SaveFile(View v){
        BitmapDrawable drawable = (BitmapDrawable) enhanced_view.getDrawable();
        Bitmap bitmap = drawable.getBitmap();

        print("Creating cw");
        ContextWrapper cw = new ContextWrapper(this.getApplicationContext());
        print("Creating dir");
        File directory = cw.getDir("ImagesDir", Context.MODE_PRIVATE);
        print("Created dir" + directory);
        File mypath=new File(directory,"myImagesDGS.jpg");
        print("path is"+mypath);

        FileOutputStream fos = null;
        try {
            print("creating fos");
            fos = new FileOutputStream(mypath);
            print("Compressing bitmap");
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
                print("fos closed");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void print(String str){
        Log.d(TAG, str);
    }
    void connectServer(View v){

        String postUrl= "http://192.168.43.175:5000";

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        // Read BitMap by file path
        // Bitmap bitmap = mImageBitmap;
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] byteArray = stream.toByteArray();

        RequestBody postBodyImage = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("image", "androidFlask.jpg", RequestBody.create(MediaType.parse("image/*jpg"), byteArray))
                .build();

        postRequest(postUrl, postBodyImage);
    }

    void postRequest(String postUrl, RequestBody postBody) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(5, TimeUnit.MINUTES) // connect timeout
                .writeTimeout(5, TimeUnit.MINUTES) // write timeout
                .readTimeout(5, TimeUnit.MINUTES); // read timeout
        OkHttpClient client = builder.build();

        //OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(postUrl)
                .post(postBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // Cancel the post on failure.
                ex=e;
                call.cancel();

                // In order to access the TextView inside the UI thread, the code is executed inside runOnUiThread()
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        Toast.makeText(Main4Activity.this, "failed to connect to the server" + ex, Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        Toast.makeText(Main4Activity.this, " next toast" + ex, Toast.LENGTH_SHORT).show();


                    }
                });
                Intent i = new Intent(getApplicationContext(),Main4Activity.class);
                i.putExtra("response", response.body().toString());
                startActivity(i);


            }
        });
    }
}

