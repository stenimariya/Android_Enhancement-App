package com.example.mprojected;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;

@SuppressWarnings("ALL")
public class Main5Activity extends AppCompatActivity {

    // Define the pic id
    private static final int pic_id = 123;

    // Define the button and imageview type variable
    ImageView result_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        result_view = (ImageView) findViewById(R.id.last_image);

        String root = Environment.getExternalStorageDirectory().getAbsolutePath();
        File myDir = new File(root);
        String fname = "Image11.jpg";
        File file = new File(myDir, fname);

        if (file.exists()) {

            Bitmap myBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

            result_view.setImageBitmap(myBitmap);

        }
    }


}
